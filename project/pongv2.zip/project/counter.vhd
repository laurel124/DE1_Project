library ieee;
use ieee.std_logic_1164.all;
use ieee.numeric_std.all;

entity counter is
    generic (
        G_BITS : positive := 3
    );
    port (
        clk : in  std_logic;
        rst : in  std_logic;
        en  : in  std_logic;
        cnt : out std_logic_vector(G_BITS - 1 downto 0)
    );
end entity counter;

architecture behavioral of counter is

    -- maximum value of the counter
    constant C_MAX : integer := 2**G_BITS - 1;

    signal sig_cnt : integer range 0 to C_MAX;

begin

    process (clk) is
    begin
        if rising_edge(clk) then
            if rst = '1' then
                sig_cnt <= 0;

            elsif en = '1' then
                if sig_cnt = C_MAX then
                    sig_cnt <= 0;
                else
                    sig_cnt <= sig_cnt + 1;
                end if;
            end if;
        end if;
    end process;

    cnt <= std_logic_vector(to_unsigned(sig_cnt, G_BITS));

end architecture behavioral;
