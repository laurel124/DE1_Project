library IEEE;
use IEEE.STD_LOGIC_1164.ALL;

entity spi is
    Port (
        clk          : in  STD_LOGIC;
        rst          : in  STD_LOGIC;
        ce           : in  STD_LOGIC;
        addres       : in  STD_LOGIC;
        spi_start    : in  STD_LOGIC;
        data_in      : in  STD_LOGIC_VECTOR (15 downto 0);
        data_out     : out STD_LOGIC;
        spi_clk_out  : out STD_LOGIC;
        cs_1         : out STD_LOGIC;
        cs_2         : out STD_LOGIC;
        spi_complete : out STD_LOGIC
    );
end spi;

architecture Behavioral of spi is
    type state_type is (IDLE, SHIFT_LOW, SHIFT_HIGH, DONE);
    signal current_state : state_type := IDLE;

    signal current_bit_index : integer range 0 to 15 := 15;
    signal shift_reg         : std_logic_vector(15 downto 0) := (others => '0');
begin
    process(clk)
    begin
        if rising_edge(clk) then
            if rst = '1' then
                current_state     <= IDLE;
                cs_1              <= '1';
                cs_2              <= '1';
                spi_complete      <= '0';
                data_out          <= '0';
                spi_clk_out       <= '0';
                current_bit_index <= 15;
                shift_reg         <= (others => '0');

            elsif ce = '1' then
                case current_state is
                    when IDLE =>
                        spi_complete <= '0';
                        cs_1         <= '1';
                        cs_2         <= '1';
                        data_out     <= '0';
                        spi_clk_out  <= '0';

                        if spi_start = '1' then
                            current_state     <= SHIFT_LOW;
                            shift_reg         <= data_in;
                            current_bit_index <= 15;
                        end if;

                    when SHIFT_LOW =>
                        spi_clk_out <= '0';

                        if addres = '0' then
                            cs_1 <= '0';
                            cs_2 <= '1';
                        else
                            cs_1 <= '1';
                            cs_2 <= '0';
                        end if;

                        data_out      <= shift_reg(current_bit_index);
                        current_state <= SHIFT_HIGH;

                    when SHIFT_HIGH =>
                        spi_clk_out <= '1';

                        if current_bit_index = 0 then
                            current_state <= DONE;
                        else
                            current_bit_index <= current_bit_index - 1;
                            current_state     <= SHIFT_LOW;
                        end if;

                    when DONE =>
                        spi_clk_out   <= '0';
                        spi_complete  <= '1';
                        cs_1          <= '1';
                        cs_2          <= '1';
                        current_state <= IDLE;

                    when others =>
                        current_state <= IDLE;
                end case;
            end if;
        end if;
    end process;
end Behavioral;
