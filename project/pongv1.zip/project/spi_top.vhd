library IEEE;
use IEEE.STD_LOGIC_1164.ALL;
use IEEE.NUMERIC_STD.ALL;

entity spi_top is
    Port (
        clk             : in  STD_LOGIC;
        rst             : in  STD_LOGIC;
        matrix_data_in  : in  STD_LOGIC_VECTOR(15 downto 0);
        matrix_addr_out : out STD_LOGIC_VECTOR(2 downto 0);
        spi_data_out    : out STD_LOGIC;
        spi_clk_out     : out STD_LOGIC;
        spi_cs_1        : out STD_LOGIC;
        spi_cs_2        : out STD_LOGIC
    );
end spi_top;

architecture Behavioral of spi_top is
    component clk_en is
        generic (
            G_MAX : positive := 5
        );
        Port (
            clk : in  STD_LOGIC;
            rst : in  STD_LOGIC;
            ce  : out STD_LOGIC
        );
    end component;

    component spi is
        Port (
            clk          : in  STD_LOGIC;
            rst          : in  STD_LOGIC;
            ce           : in  STD_LOGIC;
            addres       : in  STD_LOGIC;
            spi_start    : in  STD_LOGIC;
            data_in      : in  STD_LOGIC_VECTOR (15 downto 0);
            data_out     : out STD_LOGIC;
            spi_clk_out  : out STD_LOGIC;
            cs_1         : out STD_LOGIC;
            cs_2         : out STD_LOGIC;
            spi_complete : out STD_LOGIC
        );
    end component;

    type t_state is (LOAD_CMD, START_CMD, WAIT_CMD, ADVANCE_CMD);

    signal current_state : t_state := LOAD_CMD;
    signal s_ce          : std_logic;
    signal s_spi_start   : std_logic := '0';
    signal s_spi_comp    : std_logic;
    signal s_spi_addres  : std_logic := '0';
    signal s_spi_data_in : std_logic_vector(15 downto 0) := (others => '0');

    signal s_row_addr    : unsigned(2 downto 0) := (others => '0');
    signal s_target      : std_logic := '0';
    signal s_init_index  : integer range 0 to 4 := 0;
    signal s_init_done   : std_logic := '0';

    function make_packet(
        reg_addr : natural;
        reg_data : std_logic_vector(7 downto 0)
    ) return std_logic_vector is
        variable tmp : std_logic_vector(15 downto 0);
    begin
        tmp(15 downto 8) := std_logic_vector(to_unsigned(reg_addr, 8));
        tmp(7 downto 0)  := reg_data;
        return tmp;
    end function;

    function init_packet(idx : integer) return std_logic_vector is
    begin
        case idx is
            when 0 => return make_packet(16#0F#, x"00"); -- display test off
            when 1 => return make_packet(16#09#, x"00"); -- decode mode off
            when 2 => return make_packet(16#0B#, x"07"); -- scan limit 0..7
            when 3 => return make_packet(16#0A#, x"08"); -- intensity
            when others => return make_packet(16#0C#, x"01"); -- normal operation
        end case;
    end function;

    function row_packet(
        row_idx   : unsigned(2 downto 0);
        row_data  : std_logic_vector(7 downto 0)
    ) return std_logic_vector is
    begin
        return make_packet(to_integer(row_idx) + 1, row_data);
    end function;
begin
    matrix_addr_out <= std_logic_vector(s_row_addr);

    inst_clk_en : clk_en
        generic map (G_MAX => 250)
        port map (
            clk => clk,
            rst => rst,
            ce  => s_ce
        );

    inst_spi : spi
        port map (
            clk          => clk,
            rst          => rst,
            ce           => s_ce,
            addres       => s_spi_addres,
            spi_start    => s_spi_start,
            data_in      => s_spi_data_in,
            data_out     => spi_data_out,
            spi_clk_out  => spi_clk_out,
            cs_1         => spi_cs_1,
            cs_2         => spi_cs_2,
            spi_complete => s_spi_comp
        );

    p_fsm : process(clk)
    begin
        if rising_edge(clk) then
            if rst = '1' then
                current_state <= LOAD_CMD;
                s_spi_start   <= '0';
                s_spi_addres  <= '0';
                s_spi_data_in <= (others => '0');
                s_row_addr    <= (others => '0');
                s_target      <= '0';
                s_init_index  <= 0;
                s_init_done   <= '0';

            elsif s_ce = '1' then
                case current_state is
                    when LOAD_CMD =>
                        s_spi_start  <= '0';
                        s_spi_addres <= s_target;

                        if s_init_done = '0' then
                            s_spi_data_in <= init_packet(s_init_index);
                        else
                            if s_target = '0' then
                                s_spi_data_in <= row_packet(s_row_addr, matrix_data_in(15 downto 8));
                            else
                                s_spi_data_in <= row_packet(s_row_addr, matrix_data_in(7 downto 0));
                            end if;
                        end if;

                        current_state <= START_CMD;

                    when START_CMD =>
                        s_spi_start   <= '1';
                        current_state <= WAIT_CMD;

                    when WAIT_CMD =>
                        s_spi_start <= '0';
                        if s_spi_comp = '1' then
                            current_state <= ADVANCE_CMD;
                        end if;

                    when ADVANCE_CMD =>
                        if s_init_done = '0' then
                            if s_target = '0' then
                                s_target <= '1';
                            else
                                s_target <= '0';
                                if s_init_index = 4 then
                                    s_init_done  <= '1';
                                    s_init_index <= 0;
                                else
                                    s_init_index <= s_init_index + 1;
                                end if;
                            end if;
                        else
                            if s_target = '0' then
                                s_target <= '1';
                            else
                                s_target <= '0';
                                if s_row_addr = 7 then
                                    s_row_addr <= (others => '0');
                                else
                                    s_row_addr <= s_row_addr + 1;
                                end if;
                            end if;
                        end if;

                        current_state <= LOAD_CMD;

                    when others =>
                        current_state <= LOAD_CMD;
                end case;
            end if;
        end if;
    end process;
end Behavioral;
