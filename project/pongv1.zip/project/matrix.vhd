library IEEE;
use IEEE.STD_LOGIC_1164.ALL;
use IEEE.NUMERIC_STD.ALL;

entity matrix is
    Port ( clk    : in std_logic ;
           rst    : in std_logic;
           btn_P1 : in STD_LOGIC_VECTOR (7 downto 0);
           btn_P2 : in STD_LOGIC_VECTOR (7 downto 0);
           alu_Y  : in STD_LOGIC_VECTOR (2 downto 0);
           alu_X  : in STD_LOGIC_VECTOR (3 downto 0);
           spi_Y  : in STD_LOGIC_VECTOR (2 downto 0);
           spi_X  : out STD_LOGIC_VECTOR (15 downto 0));
end matrix;

architecture Behavioral of matrix is
    type MAT is array (7 downto 0) of std_logic_vector(15 downto 0);
    signal mat_table : MAT := (others => (others => '0'));
begin
    p_matrix : process(clk)
        variable tmp   : MAT;
        variable x_idx : integer;
        variable y_idx : integer;
    begin
        if rising_edge(clk) then
            if rst = '1' then
                mat_table <= (others => (others => '0'));
                spi_X <= x"0000";
            else
                tmp := (others => (others => '0'));

                for i in 0 to 7 loop
                    if btn_P1(i) = '1' then
                        tmp(i)(0) := '1';
                    end if;
                end loop;

                for i in 0 to 7 loop
                    if btn_P2(i) = '1' then
                        tmp(i)(15) := '1';
                    end if;
                end loop;

                x_idx := to_integer(unsigned(alu_X)) + 1;
                y_idx := to_integer(unsigned(alu_Y));

                if (x_idx >= 0 and x_idx <= 15 and y_idx >= 0 and y_idx <= 7) then
                    tmp(y_idx)(x_idx) := '1';
                end if;

                mat_table <= tmp;
                spi_X <= tmp(to_integer(unsigned(spi_Y)));
            end if;
        end if;
    end process;
end Behavioral;
